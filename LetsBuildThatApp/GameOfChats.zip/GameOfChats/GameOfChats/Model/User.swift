//
//  User.swift
//  GameOfChats
//
//  Created by 강준영 on 16/12/2018.
//  Copyright © 2018 강준영. All rights reserved.
//

import UIKit

class User: NSObject {
    var email: String?
    var name: String?
}
